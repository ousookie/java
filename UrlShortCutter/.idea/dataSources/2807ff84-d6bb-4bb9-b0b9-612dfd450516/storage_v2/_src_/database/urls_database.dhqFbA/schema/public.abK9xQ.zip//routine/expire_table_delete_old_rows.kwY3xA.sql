create function expire_table_delete_old_rows() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM url WHERE timestamp < NOW() - INTERVAL '10 minute';
    RETURN NEW;
END;
$$;

alter function expire_table_delete_old_rows() owner to postgres;

